<!--
<div class="row" style="padding:1% 0">
    <div class="col-md-12">
        <div class="pull-right">
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                photos Details
            </header>
           
                   <?php foreach($before as $row){
    print_r($row);}?>
                       <?php foreach($before as $row){?>
                        <input type="text" id="normal-field" class="form-control" name="order" value="<?php echo $row->id;?>">
                           
                <?php}?>
               
        </section>
        </div>
    </div>
-->

                
        